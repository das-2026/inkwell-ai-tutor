/**
 * Inkwell BACKEND (Supabase edition) — Cloudflare Worker
 * ============================================================
 * Same API as before, but data lives in Supabase (Postgres)
 * instead of KV. The app is unchanged. The Worker talks to
 * Supabase with the SERVICE_ROLE key (server-only), so the
 * browser never touches the database.
 *
 * SECRETS (wrangler secret put NAME):
 *   ANTHROPIC_API_KEY
 *   OPENAI_API_KEY          (optional, AI voice)
 *   FLW_SECRET_KEY          (Flutterwave secret)
 *   FLW_WEBHOOK_HASH
 *   AUTH_PEPPER
 *   SUPABASE_URL            e.g. https://abcd.supabase.co
 *   SUPABASE_SERVICE_KEY    the service_role key (NOT the anon key)
 * ============================================================
 */

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const ANTHROPIC_VERSION = "2023-06-01";
const OPENAI_TTS_URL = "https://api.openai.com/v1/audio/speech";
const FLW_URL = "https://api.flutterwave.com/v3";

const ALLOWED_ORIGINS = ["*"]; // set to your real origin(s) for production
const ALLOWED_MODELS = ["claude-sonnet-4-6"];
const TTS_MODEL = "gpt-4o-mini-tts";
const ALLOWED_VOICES = ["alloy","ash","ballad","coral","echo","fable","nova","onyx","sage","shimmer"];

const CREDITS_PER_CEDI = 10000 / 60;
const PRICE_TUTOR=50, PRICE_MARK=80, PRICE_TTS=20, PRICE_MODULE=500, SIGNUP_BONUS=500;
function creditsForAmount(c){ return Math.round(c*CREDITS_PER_CEDI); }

function cors(o){ const a=ALLOWED_ORIGINS.includes("*")?"*":(ALLOWED_ORIGINS.includes(o)?o:ALLOWED_ORIGINS[0]||"");
  return {"Access-Control-Allow-Origin":a,"Access-Control-Allow-Methods":"POST, GET, OPTIONS","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Max-Age":"86400","Vary":"Origin"}; }
function json(b,s,o){ return new Response(JSON.stringify(b),{status:s,headers:{"Content-Type":"application/json",...cors(o)}}); }
async function sha256(str){ const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(str)); return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join(""); }
function token(){ return crypto.randomUUID().replace(/-/g,"")+crypto.randomUUID().replace(/-/g,""); }
function normPhone(p){ return (p||"").replace(/[^\d+]/g,""); }

/* ---- Supabase REST helpers (PostgREST + RPC) ---- */
function sb(env, path, opts={}){
  const headers = Object.assign({
    "apikey": env.SUPABASE_SERVICE_KEY,
    "Authorization": "Bearer "+env.SUPABASE_SERVICE_KEY,
    "Content-Type": "application/json"
  }, opts.headers||{});
  return fetch(env.SUPABASE_URL.replace(/\/+$/,"")+"/rest/v1"+path, Object.assign({}, opts, {headers}));
}
async function sbSelect(env, table, query){
  const r = await sb(env, "/"+table+"?"+query, {method:"GET"});
  if(!r.ok) throw new Error("DB read failed: "+(await r.text()));
  return r.json();
}
async function sbInsert(env, table, row, opts={}){
  const headers = {"Prefer": opts.upsert?"resolution=merge-duplicates,return=representation":"return=representation"};
  const r = await sb(env, "/"+table, {method:"POST", headers, body:JSON.stringify(row)});
  if(!r.ok) throw new Error("DB write failed: "+(await r.text()));
  return r.json();
}
async function sbUpdate(env, table, query, patch){
  const r = await sb(env, "/"+table+"?"+query, {method:"PATCH", headers:{"Prefer":"return=representation"}, body:JSON.stringify(patch)});
  if(!r.ok) throw new Error("DB update failed: "+(await r.text()));
  return r.json();
}
async function sbRpc(env, fn, args){
  const r = await sb(env, "/rpc/"+fn, {method:"POST", body:JSON.stringify(args)});
  if(!r.ok) throw new Error("DB rpc failed: "+(await r.text()));
  return r.json();
}

async function getUser(env, phone){
  const rows = await sbSelect(env, "users", "phone=eq."+encodeURIComponent(phone)+"&select=*");
  return rows[0]||null;
}
async function getUnlocks(env, phone){
  const rows = await sbSelect(env, "unlocks", "phone=eq."+encodeURIComponent(phone)+"&select=module_id");
  return rows.map(r=>r.module_id);
}
async function userFromAuth(env, request){
  const tok = (request.headers.get("Authorization")||"").replace(/^Bearer\s+/i,"").trim();
  if(!tok) return null;
  const rows = await sbSelect(env, "sessions", "token=eq."+encodeURIComponent(tok)+"&select=phone,expires_at");
  const s = rows[0];
  if(!s) return null;
  if(new Date(s.expires_at).getTime() < Date.now()) return null;
  const u = await getUser(env, s.phone);
  return u ? {user:u, token:tok} : null;
}
function sessionExpiry(){ return new Date(Date.now()+1000*60*60*24*60).toISOString(); } // 60 days

export default {
  async fetch(request, env){
    const origin = request.headers.get("Origin")||"";
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/,"")||"/";
    if(request.method==="OPTIONS") return new Response(null,{status:204,headers:cors(origin)});

    try{
      if(path==="/" ) return json({ok:true, service:"inkwell-supabase"},200,origin);

      // ---------- AUTH ----------
      if(path==="/auth/signup" && request.method==="POST"){
        const {phone, pin} = await request.json();
        const ph = normPhone(phone);
        if(ph.length<7 || !pin || (""+pin).length<4) return json({error:"Enter a valid phone and a PIN of at least 4 digits."},400,origin);
        const placeholder = await sha256(ph+":__landing__:"+(env.AUTH_PEPPER||""));
        const existing = await getUser(env, ph);
        const pin_hash = await sha256(ph+":"+pin+":"+(env.AUTH_PEPPER||""));
        if(existing){
          // Allow claiming a placeholder account created by a landing-page purchase.
          if(existing.pin_hash === placeholder){
            await sbUpdate(env, "users", "phone=eq."+encodeURIComponent(ph), {pin_hash, credits: existing.credits + SIGNUP_BONUS});
            const t = token();
            await sbInsert(env, "sessions", {token:t, phone:ph, expires_at:sessionExpiry()});
            const unlocked = await getUnlocks(env, ph);
            return json({token:t, phone:ph, credits: existing.credits + SIGNUP_BONUS, unlocked, bonus:SIGNUP_BONUS},200,origin);
          }
          return json({error:"That phone is already registered. Please log in."},409,origin);
        }
        await sbInsert(env, "users", {phone:ph, pin_hash, credits:SIGNUP_BONUS});
        const t = token();
        await sbInsert(env, "sessions", {token:t, phone:ph, expires_at:sessionExpiry()});
        return json({token:t, phone:ph, credits:SIGNUP_BONUS, unlocked:[], bonus:SIGNUP_BONUS},200,origin);
      }
      if(path==="/auth/login" && request.method==="POST"){
        const {phone, pin} = await request.json();
        const ph = normPhone(phone);
        const u = await getUser(env, ph);
        if(!u) return json({error:"No account for that phone. Please sign up."},404,origin);
        const pin_hash = await sha256(ph+":"+pin+":"+(env.AUTH_PEPPER||""));
        if(pin_hash!==u.pin_hash) return json({error:"Wrong PIN."},401,origin);
        const t = token();
        await sbInsert(env, "sessions", {token:t, phone:ph, expires_at:sessionExpiry()});
        const unlocked = await getUnlocks(env, ph);
        return json({token:t, phone:ph, credits:u.credits, unlocked},200,origin);
      }
      if(path==="/me" && request.method==="GET"){
        const a = await userFromAuth(env, request);
        if(!a) return json({error:"Not logged in."},401,origin);
        const unlocked = await getUnlocks(env, a.user.phone);
        return json({phone:a.user.phone, credits:a.user.credits, unlocked},200,origin);
      }

      // ---------- PAYMENTS ----------
      // Public top-up from the landing page (no login token). Buyer gives phone+amount.
      // If the phone has no account yet, create one (zero credits) so the webhook can credit it.
      if(path==="/pay/initiate-public" && request.method==="POST"){
        const {phone, amount, redirect_url} = await request.json();
        const ph = normPhone(phone);
        if(ph.length<7) return json({error:"Enter a valid phone number."},400,origin);
        const cedis = Math.max(1, Math.round(Number(amount)||0));
        const credits = creditsForAmount(cedis);
        let u = await getUser(env, ph);
        if(!u){
          // create a placeholder account; the user sets a real PIN when they sign up in-app.
          const pin_hash = await sha256(ph+":__landing__:"+(env.AUTH_PEPPER||""));
          await sbInsert(env, "users", {phone:ph, pin_hash, credits:0});
        }
        const ref = "INKWELL-"+ph+"-"+Date.now();
        await sbInsert(env, "transactions", {tx_ref:ref, phone:ph, cedis, credits, status:"pending"});
        const body = {
          tx_ref: ref, amount: cedis, currency: "GHS",
          redirect_url: redirect_url || (url.origin+"/pay/return"),
          customer: { phonenumber:ph, email:ph+"@inkwell.app", name:ph },
          customizations: { title:"Inkwell Credits", description:credits+" credits" },
          meta: { phone:ph, credits }
        };
        const r = await fetch(FLW_URL+"/payments", {method:"POST", headers:{"Content-Type":"application/json","Authorization":"Bearer "+env.FLW_SECRET_KEY}, body:JSON.stringify(body)});
        const data = await r.json();
        if(data.status!=="success") return json({error:"Could not start payment.", detail:data.message||""},502,origin);
        return json({link:data.data.link, tx_ref:ref, credits},200,origin);
      }

      if(path==="/pay/initiate" && request.method==="POST"){
        const a = await userFromAuth(env, request);
        if(!a) return json({error:"Log in first."},401,origin);
        const {amount, redirect_url} = await request.json();
        const cedis = Math.max(1, Math.round(Number(amount)||0));
        const credits = creditsForAmount(cedis);
        const ref = "INKWELL-"+a.user.phone+"-"+Date.now();
        await sbInsert(env, "transactions", {tx_ref:ref, phone:a.user.phone, cedis, credits, status:"pending"});
        const body = {
          tx_ref: ref, amount: cedis, currency: "GHS",
          redirect_url: redirect_url || (url.origin+"/pay/return"),
          customer: { phonenumber:a.user.phone, email:a.user.phone+"@inkwell.app", name:a.user.phone },
          customizations: { title:"Inkwell Credits", description:credits+" credits" },
          meta: { phone:a.user.phone, credits }
        };
        const r = await fetch(FLW_URL+"/payments", {method:"POST", headers:{"Content-Type":"application/json","Authorization":"Bearer "+env.FLW_SECRET_KEY}, body:JSON.stringify(body)});
        const data = await r.json();
        if(data.status!=="success") return json({error:"Could not start payment.", detail:data.message||""},502,origin);
        return json({link:data.data.link, tx_ref:ref, credits},200,origin);
      }
      if(path==="/pay/webhook" && request.method==="POST"){
        const sig = request.headers.get("verif-hash")||"";
        if(!env.FLW_WEBHOOK_HASH || sig!==env.FLW_WEBHOOK_HASH) return json({error:"bad signature"},401,origin);
        const evt = await request.json();
        const d = evt.data||{};
        if(d.status==="successful" && d.tx_ref){
          const vr = await fetch(FLW_URL+"/transactions/"+d.id+"/verify", {headers:{"Authorization":"Bearer "+env.FLW_SECRET_KEY}});
          const v = await vr.json();
          if(v.status==="success" && v.data.status==="successful" && v.data.currency==="GHS"){
            const rows = await sbSelect(env, "transactions", "tx_ref=eq."+encodeURIComponent(d.tx_ref)+"&select=*");
            const tx = rows[0];
            if(tx && tx.status!=="credited" && v.data.amount>=tx.cedis){
              await sbRpc(env, "credit_topup", {p_tx_ref: d.tx_ref});
            }
          }
        }
        return json({ok:true},200,origin);
      }
      if(path==="/pay/status" && request.method==="POST"){
        const a = await userFromAuth(env, request);
        if(!a) return json({error:"Log in first."},401,origin);
        const {tx_ref} = await request.json();
        const rows = await sbSelect(env, "transactions", "tx_ref=eq."+encodeURIComponent(tx_ref)+"&select=status");
        const u = await getUser(env, a.user.phone);
        return json({status: rows[0]?rows[0].status:"unknown", credits: u?u.credits:0},200,origin);
      }

      // ---------- CREDIT-GATED ----------
      if(path==="/unlock" && request.method==="POST"){
        const a = await userFromAuth(env, request);
        if(!a) return json({error:"Log in first."},401,origin);
        const {moduleId} = await request.json();
        const have = await getUnlocks(env, a.user.phone);
        if(have.includes(moduleId)){ return json({ok:true, credits:a.user.credits, unlocked:have},200,origin); }
        const bal = await sbRpc(env, "spend_credits", {p_phone:a.user.phone, p_cost:PRICE_MODULE, p_action:"unlock"});
        if(bal===-1) return json({error:"Not enough credits.", need:PRICE_MODULE, credits:a.user.credits},402,origin);
        await sbInsert(env, "unlocks", {phone:a.user.phone, module_id:moduleId}, {upsert:true});
        const unlocked = await getUnlocks(env, a.user.phone);
        return json({ok:true, credits:bal, unlocked, spent:PRICE_MODULE},200,origin);
      }
      if(path==="/ai" && request.method==="POST"){
        const a = await userFromAuth(env, request);
        if(!a) return json({error:"Log in first."},401,origin);
        const {system, userText, purpose, model, max_tokens} = await request.json();
        const cost = purpose==="mark"?PRICE_MARK:PRICE_TUTOR;
        if(a.user.credits < cost) return json({error:"Not enough credits.", need:cost, credits:a.user.credits},402,origin);
        if(model && !ALLOWED_MODELS.includes(model)) return json({error:"Model not allowed."},400,origin);
        const r = await fetch(ANTHROPIC_URL, {method:"POST", headers:{"Content-Type":"application/json","x-api-key":env.ANTHROPIC_API_KEY,"anthropic-version":ANTHROPIC_VERSION}, body:JSON.stringify({model:model||ALLOWED_MODELS[0], max_tokens:Math.min(Number(max_tokens)||1000,1500), system, messages:[{role:"user",content:userText}]})});
        if(!r.ok){ const t=await r.text(); return new Response(t,{status:r.status,headers:{"Content-Type":"application/json",...cors(origin)}}); }
        const data = await r.json();
        const bal = await sbRpc(env, "spend_credits", {p_phone:a.user.phone, p_cost:cost, p_action:purpose==="mark"?"mark":"tutor"});
        const text = (data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("\n");
        return json({text, credits: bal===-1?a.user.credits:bal, spent:cost},200,origin);
      }
      if(path==="/tts" && request.method==="POST"){
        const a = await userFromAuth(env, request);
        if(!a) return json({error:"Log in first."},401,origin);
        if(!env.OPENAI_API_KEY) return json({error:"Voice not configured."},500,origin);
        if(a.user.credits < PRICE_TTS) return json({error:"Not enough credits.", need:PRICE_TTS, credits:a.user.credits},402,origin);
        const {input, voice} = await request.json();
        const v = ALLOWED_VOICES.includes(voice)?voice:"alloy";
        const inp = (input||"").toString().slice(0,1200);
        if(!inp.trim()) return json({error:"No text."},400,origin);
        const r = await fetch(OPENAI_TTS_URL, {method:"POST", headers:{"Content-Type":"application/json","Authorization":"Bearer "+env.OPENAI_API_KEY}, body:JSON.stringify({model:TTS_MODEL, voice:v, input:inp, response_format:"mp3"})});
        if(!r.ok){ const t=await r.text(); return new Response(t,{status:r.status,headers:{"Content-Type":"application/json",...cors(origin)}}); }
        const bal = await sbRpc(env, "spend_credits", {p_phone:a.user.phone, p_cost:PRICE_TTS, p_action:"tts"});
        return new Response(r.body, {status:200, headers:{"Content-Type":"audio/mpeg","X-Credits":String(bal),...cors(origin)}});
      }

      if(path==="/pricing" && request.method==="GET"){
        return json({rate_credits_per_cedi:Math.round(CREDITS_PER_CEDI*100)/100,
          packs:[60,120,180,240,300,360,420,480,540,600].map(c=>({cedis:c,credits:creditsForAmount(c)})),
          costs:{tutor:PRICE_TUTOR,mark:PRICE_MARK,tts:PRICE_TTS,module:PRICE_MODULE}, signup_bonus:SIGNUP_BONUS},200,origin);
      }
      if(path==="/pay/return") return new Response("<h2>Payment received. You can return to Inkwell.</h2>",{headers:{"Content-Type":"text/html",...cors(origin)}});

      return json({error:"Not found: "+path},404,origin);
    }catch(e){
      return json({error:"Server error: "+e.message},500,origin);
    }
  }
};
