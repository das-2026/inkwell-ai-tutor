# Inkwell Backend with Supabase — setup

The app stays the same. Data (users, credits, payments) lives in Supabase
Postgres. The Cloudflare Worker talks to Supabase with the **service_role**
key, so the browser never touches the database.

## 1. Create the Supabase project
1. Go to https://supabase.com → New project (free tier is fine). Pick a region close to your users.
2. When it's ready, open **SQL Editor → New query**, paste ALL of `schema.sql`, and click **Run**.
   This creates the tables, locks them with Row Level Security (no public access),
   and adds the safe `spend_credits` / `credit_topup` functions.

## 2. Get your keys
In Supabase: **Project Settings → API**. You need:
- **Project URL**  → `SUPABASE_URL`  (e.g. https://abcd1234.supabase.co)
- **service_role key** (under "Project API keys", click reveal) → `SUPABASE_SERVICE_KEY`
  ⚠️ This is a SECRET. Never put it in the app or share it. The Worker only.
  (Do NOT use the `anon` key here — the Worker needs service_role to bypass RLS.)

## 3. Deploy the Worker
```
npm install -g wrangler
wrangler login
wrangler secret put ANTHROPIC_API_KEY
wrangler secret put OPENAI_API_KEY        # optional, for AI voice
wrangler secret put FLW_SECRET_KEY         # Flutterwave secret key
wrangler secret put FLW_WEBHOOK_HASH        # any phrase; paste same in Flutterwave dashboard
wrangler secret put AUTH_PEPPER            # any long random text
wrangler secret put SUPABASE_URL
wrangler secret put SUPABASE_SERVICE_KEY
wrangler deploy
```
Copy the printed URL → paste into the app: **Account tab → server URL → Save**.

## 4. Flutterwave webhook
Dashboard → Settings → Webhooks:
- URL: `https://YOUR-worker-url/pay/webhook`
- Secret hash: the same text you set for `FLW_WEBHOOK_HASH`.

## Why this is safe
- RLS is ON with no public policies → the anon/public key can read/write NOTHING.
- Only the Worker (service_role) reaches the data.
- Credits are spent via a single atomic SQL function (`spend_credits`) so two
  requests can't double-spend.
- Top-ups are credited via `credit_topup`, which is idempotent (a repeated
  webhook can't add credits twice).

## Tables you can browse in Supabase
- `users` (phone, credits) · `unlocks` · `sessions` · `transactions` · `usage_log`
You now have a real dashboard: revenue (transactions), spend (usage_log), balances (users).

## Going live
- Set `ALLOWED_ORIGINS` in `src/index.js` to your real site before public launch.
- Test with Flutterwave TEST keys first; confirm a top-up lands in `transactions`
  (status `credited`) and the user's `credits` rise, before using live keys.
