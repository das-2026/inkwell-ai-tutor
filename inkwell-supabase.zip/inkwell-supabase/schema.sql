-- ============================================================
-- Inkwell — Supabase schema
-- Run this in: Supabase dashboard → SQL Editor → New query → Run
-- ============================================================
-- The app NEVER talks to these tables directly. Only the Cloudflare
-- Worker does, using the service_role key. We therefore enable RLS
-- and add NO public policies, so the anon/public key cannot read or
-- write anything. The service_role key bypasses RLS by design.
-- ============================================================

-- 1) USERS ---------------------------------------------------
create table if not exists public.users (
  phone        text primary key,
  pin_hash     text not null,
  credits      bigint not null default 0,
  created_at   timestamptz not null default now()
);

-- 2) UNLOCKED MODULES (one row per user+module) --------------
create table if not exists public.unlocks (
  phone        text not null references public.users(phone) on delete cascade,
  module_id    text not null,
  created_at   timestamptz not null default now(),
  primary key (phone, module_id)
);

-- 3) SESSIONS (token -> phone, with expiry) ------------------
create table if not exists public.sessions (
  token        text primary key,
  phone        text not null references public.users(phone) on delete cascade,
  expires_at   timestamptz not null
);
create index if not exists sessions_phone_idx on public.sessions(phone);

-- 4) TRANSACTIONS (top-ups; idempotent crediting) -----------
create table if not exists public.transactions (
  tx_ref       text primary key,
  phone        text not null,
  cedis        integer not null,
  credits      bigint not null,
  status       text not null default 'pending',   -- pending | credited
  created_at   timestamptz not null default now(),
  credited_at  timestamptz
);
create index if not exists tx_phone_idx on public.transactions(phone);

-- 5) USAGE LOG (optional: every credit spend, for reporting) -
create table if not exists public.usage_log (
  id           bigint generated always as identity primary key,
  phone        text not null,
  action       text not null,      -- tutor | mark | tts | unlock
  cost         integer not null,
  created_at   timestamptz not null default now()
);
create index if not exists usage_phone_idx on public.usage_log(phone);

-- ============================================================
-- LOCK EVERYTHING DOWN: enable RLS, add no policies.
-- With RLS on and no policies, the public anon key is fully denied.
-- The Worker uses the service_role key, which bypasses RLS.
-- ============================================================
alter table public.users        enable row level security;
alter table public.unlocks      enable row level security;
alter table public.sessions     enable row level security;
alter table public.transactions enable row level security;
alter table public.usage_log    enable row level security;

-- ============================================================
-- Helper: atomically spend credits (prevents race conditions /
-- double-spend). Returns the new balance, or -1 if insufficient.
-- ============================================================
create or replace function public.spend_credits(p_phone text, p_cost integer, p_action text)
returns bigint
language plpgsql
security definer
as $$
declare
  new_balance bigint;
begin
  update public.users
     set credits = credits - p_cost
   where phone = p_phone and credits >= p_cost
   returning credits into new_balance;

  if new_balance is null then
    return -1;            -- not enough credits (or no such user)
  end if;

  insert into public.usage_log(phone, action, cost) values (p_phone, p_action, p_cost);
  return new_balance;
end;
$$;

-- ============================================================
-- Helper: atomically add credits for a verified, not-yet-credited
-- transaction. Returns true if it credited, false if already done.
-- ============================================================
create or replace function public.credit_topup(p_tx_ref text)
returns boolean
language plpgsql
security definer
as $$
declare
  tx record;
begin
  select * into tx from public.transactions where tx_ref = p_tx_ref for update;
  if not found then return false; end if;
  if tx.status = 'credited' then return false; end if;

  update public.users set credits = credits + tx.credits where phone = tx.phone;
  update public.transactions set status = 'credited', credited_at = now() where tx_ref = p_tx_ref;
  return true;
end;
$$;
